
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    void addDeleteUpdateFlow() {
        ContactService s = new ContactService();
        Contact c = new Contact("1","A","B","1234567890","Addr");
        s.addContact(c);
        s.updateFirstName("1","Z");
        assertEquals("Z", c.getFirstName());
        s.deleteContact("1");
    }

    @Test
    void duplicateFails() {
        ContactService s = new ContactService();
        Contact c = new Contact("1","A","B","1234567890","Addr");
        s.addContact(c);
        assertThrows(IllegalArgumentException.class, () -> s.addContact(c));
    }
}
