
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void validContact() {
        Contact c = new Contact("1","Amy","Lee","1234567890","Addr");
        assertEquals("Amy", c.getFirstName());
    }

    @Test void idNull() { assertThrows(IllegalArgumentException.class, () -> new Contact(null,"A","B","1234567890","Addr")); }
    @Test void idTooLong() { assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901","A","B","1234567890","Addr")); }
    @Test void firstNull() { assertThrows(IllegalArgumentException.class, () -> new Contact("1",null,"B","1234567890","Addr")); }
    @Test void lastTooLong() { assertThrows(IllegalArgumentException.class, () -> new Contact("1","A","12345678901","1234567890","Addr")); }
    @Test void phoneInvalid() { assertThrows(IllegalArgumentException.class, () -> new Contact("1","A","B","123","Addr")); }
    @Test void addressTooLong() { assertThrows(IllegalArgumentException.class, () -> new Contact("1","A","B","1234567890","x".repeat(31))); }

    @Test
    void settersWork() {
        Contact c = new Contact("1","A","B","1234567890","Addr");
        c.setFirstName("Z");
        c.setLastName("Y");
        c.setPhone("0987654321");
        c.setAddress("New");
        assertEquals("Z", c.getFirstName());
    }
}
