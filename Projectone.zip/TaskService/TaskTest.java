
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test void valid() {
        Task t = new Task("1","Name","Desc");
        assertEquals("Name", t.getName());
    }

    @Test void nullName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Desc"));
    }

    @Test void longDesc() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1","Name","x".repeat(51)));
    }

    @Test void setters() {
        Task t = new Task("1","A","B");
        t.setName("Z");
        t.setDescription("Y");
        assertEquals("Z", t.getName());
    }
}
