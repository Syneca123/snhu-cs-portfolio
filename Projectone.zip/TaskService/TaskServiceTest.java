
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    void fullFlow() {
        TaskService s = new TaskService();
        Task t = new Task("1","A","B");
        s.addTask(t);
        s.updateName("1","Z");
        assertEquals("Z", t.getName());
        s.deleteTask("1");
    }

    @Test
    void duplicateFails() {
        TaskService s = new TaskService();
        Task t = new Task("1","A","B");
        s.addTask(t);
        assertThrows(IllegalArgumentException.class, () -> s.addTask(t));
    }
}
