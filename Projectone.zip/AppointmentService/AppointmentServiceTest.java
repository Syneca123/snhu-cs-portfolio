
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    @Test
    void fullFlow() {
        AppointmentService s = new AppointmentService();
        Appointment a = new Appointment("1", new Date(System.currentTimeMillis()+10000), "Meet");
        s.addAppointment(a);
        s.deleteAppointment("1");
    }

    @Test
    void duplicateFails() {
        AppointmentService s = new AppointmentService();
        Appointment a = new Appointment("1", new Date(System.currentTimeMillis()+10000), "Meet");
        s.addAppointment(a);
        assertThrows(IllegalArgumentException.class, () -> s.addAppointment(a));
    }
}
