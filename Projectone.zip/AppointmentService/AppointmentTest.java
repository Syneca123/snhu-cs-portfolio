
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test void valid() {
        Appointment a = new Appointment("1", new Date(System.currentTimeMillis()+10000), "Meet");
        assertEquals("Meet", a.getDescription());
    }

    @Test void pastFails() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", new Date(0), "Bad"));
    }

    @Test void nullFails() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "Bad"));
    }
}
