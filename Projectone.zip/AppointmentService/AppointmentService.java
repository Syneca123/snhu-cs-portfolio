
import java.util.HashMap;

public class AppointmentService {
    private HashMap<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment a) {
        if (appointments.containsKey(a.getAppointmentId())) throw new IllegalArgumentException();
        appointments.put(a.getAppointmentId(), a);
    }

    public void deleteAppointment(String id) {
        appointments.remove(id);
    }
}
